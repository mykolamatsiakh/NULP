CREATE TRIGGER AfterInsertVlasnykAvtosalon
AFTER INSERT ON vlasnyk_avtosalon
FOR EACH ROW
  BEGIN
	DECLARE name_vlasnyk VARCHAR(50);
    DECLARE name_avtosalon VARCHAR(90);
    SELECT CONCAT(surname, ' ', name) INTO name_vlasnyk
    FROM vlasnyk WHERE vlasnyk.vlasnyk_id=new.vlasnyk_id;
    SELECT CONCAT(avtosalon_name, ' / ', Author) INTO name_avtosalon
    FROM avtosalon WHERE avtosalon.avtosalon_id=new.avtosalon_id;
	INSERT INTO logger (vlasnyk, avtosalon, action,
								time_stamp, user)
	VALUES(name_vlasnyk,  name_avtosalon, 'GOT', NOW(), USER() );
END;
