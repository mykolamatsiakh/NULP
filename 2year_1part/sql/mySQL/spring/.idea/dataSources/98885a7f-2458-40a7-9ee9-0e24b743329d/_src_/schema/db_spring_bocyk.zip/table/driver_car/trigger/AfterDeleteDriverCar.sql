CREATE TRIGGER AfterDeleteDriverCar
AFTER DELETE ON driver_car
FOR EACH ROW
  BEGIN
	DECLARE name_driver VARCHAR(50);
    DECLARE name_car VARCHAR(90);
    SELECT CONCAT(surname, ' ', name) INTO name_driver
    FROM person WHERE driver_id=old.driver_id;
    SELECT CONCAT(car_name, ' / ', author) INTO name_car
    FROM car WHERE car.car_id=old.car_id;
	INSERT INTO Logger (driver, car, action,
                      time_stamp, user)
	VALUES(name_person,  name_book, 'GAVEBACK', NOW(), USER() );
END;
