CREATE TRIGGER AfterInsertDriverCar
AFTER INSERT ON driver_car
FOR EACH ROW
  BEGIN
	DECLARE name_driver VARCHAR(50);
    DECLARE name_car VARCHAR(90);
    SELECT CONCAT(surname, ' ', name) INTO name_driver
    FROM driver WHERE driver.driver_id=new.driver_id;
    SELECT CONCAT(car_name, ' / ', Author) INTO name_car
    FROM car WHERE car_id=new.car_id;
	INSERT INTO logger (driver, car, action,
								time_stamp, user)
	VALUES(name_driver,  name_car, 'GOT', NOW(), USER() );
END;
