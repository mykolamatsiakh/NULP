CREATE PROCEDURE InsertVlasnykDetail(IN SurnameVlasnykIn VARCHAR(25), IN DetailNameIN VARCHAR(45))
  BEGIN
    DECLARE msg varchar(40);

    -- checks for present Surname
    IF NOT EXISTS( SELECT * FROM Vlasnyk WHERE Surname=SurnameVlasnykIn)
    THEN SET msg = 'This Surname is absent';

    -- checks for present Detail
    ELSEIF NOT EXISTS( SELECT * FROM Detail WHERE DetailName=DetailNameIN)
      THEN SET msg = 'This Detail is absent';

    -- checks if there are this combination already
    ELSEIF EXISTS( SELECT * FROM vlasnykdetail
    WHERE IDVlasnyk = (SELECT IDVlasnyk FROM Vlasnyk WHERE Surname=SurnameVlasnykIn)
          AND IDDetail = (SELECT IDDetail FROM Detail WHERE DetailName=DetailNameIN)
    )
      THEN SET msg = 'This Vlasnyk already has this book';

    -- checks whether there is still such a book
    ELSEIF (SELECT Amount FROM Detail WHERE DetailName=DetailNameIN )
           <= (SELECT COUNT(*) FROM vlasnykdetail WHERE IDDetail=(SELECT IDDetail FROM Detail WHERE DetailName=DetailNameIN) )
      THEN SET msg = 'There are no this Detail already';

    -- makes insert
    ELSE
      INSERT vlasnykdetail (IDVlasnyk, IDDetail)
        Value ( (SELECT IDVlasnyk FROM Vlasnyk WHERE Surname=SurnameVlasnykIn),
                (SELECT IDDetail FROM Detail WHERE DetailName=DetailNameIN) );
      SET msg = 'OK';

    END IF;

    SELECT msg AS msg;

  END;

